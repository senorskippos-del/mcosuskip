# Чеклист портирования McEngine/McOsu -> Android

## Порядок работ

1. [ ] Стартовый APK с SDL2 + заглушкой `android_main.cpp` (оранжевый экран,
       тап закрывает). Проверяет весь пайплайн: NDK, SDL2, подпись, установка.
2. [ ] Компиляция McEngine: идём по ошибкам лога, исключаем/чиним файлы
       (правим `list(FILTER ...)` в android/cmake/CMakeLists.txt):
       - WinAPI-файлы (WinEnvironment, registry, виндовые окна)
       - X11/прямой GL-декстоп
       - Заменить включения <GL/gl.h> на <GLES2/gl2.h> (shim-заголовки в android/src/)
3. [ ] Рендерер: GLSL 120 -> GLSL ES 100. Типичные замены:
       `attribute/varying` -> `in/out` (ES 3.0) или оставить ES 1.00-синтаксис;
       `gl_FragColor` в ES 1.00 ок; текстуры `GL_CLAMP` -> `GL_CLAMP_TO_EDGE`.
4. [ ] Аудио: SDL2 на Android ходит через AAudio. Минимальный буфер:
       `SDL_OpenAudioDevice(..., &want, &have, SDL_AUDIO_ALLOW_SAMPLES_CHANGE)`
       с want.samples = 256; мерить реальную задержку (на realme C71 будет видно).
       Если не хватает — резать звук через Oboe напрямую.
5. [ ] Ввод: SDL сам шлёт тач как мышь (курсор = палец, тап = ЛКМ).
       Двухпальцевый тап -> правый клик (обработка в SDL_FINGERDOWN).
6. [ ] Ресурсы: пакуем assets/ шрифтов/иконок в APK (AAssetManager + мост в
       McEngine ResourceManager) ЛИО кладём рядом с osu!-папкой на /sdcard.
7. [ ] Папка osu!: /sdcard/Android/data/com.mcosu.port/files/osu!/Songs
       (обход scoped storage), настройка конфига McOsu на этот путь.

## Проверка аудиолатентности на устройстве

- В McOsu есть опции сдвига тайминга (Universal Offset) — подгоняется на слух
  по известной карте; цель: ±0 мс стабильно.
- Если звук запаздывает нестабильно — писать патч SDL audio -> Oboe.

## Отладка без ПК

- Логи workflow: Artifacts -> build-logs
- Логи приложения на девайсе: приложения-читалки logcat (нужно ADB-разрешение,
  либо добавить в McEngine запись лога в файл в папку osu!)

## Правовые рамки

- Не использовать название/логотип osu!, хитсаунды и скины из игры
- Битмапы: пользователь сам подкладывает в папку Songs
- Не публиковать APK с кодом McOsu в сторах без согласования с McKay
