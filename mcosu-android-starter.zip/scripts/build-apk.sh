#!/usr/bin/env bash
# Сборка McOsu -> Android APK без Gradle:
# NDK (r26d) + SDK build-tools (aapt2/d8/apksigner) + SDL2 из исходников.
set -uo pipefail   # НЕ ставим -e: хотим дойти до упавшего шага с понятным логом

ROOT=$PWD
DEPS=$ROOT/deps
BUILD=$ROOT/build
OUT=$ROOT/out
UNZ=$BUILD/unpacked

SDL_TAG=${SDL_TAG:-release-2.30.9}
NDK_VER=${NDK_VER:-r26d}
ANDROID_API=${ANDROID_API:-24}
ABI=${ABI:-arm64-v8a}
BT_VER=34.0.0
PKG_NAME=com.mcosu.port

step() { echo; echo "=== $* ==="; }

# ---------- 1. NDK ----------
step "1/8. Android NDK $NDK_VER"
if [ ! -d "$DEPS/android-ndk-$NDK_VER" ]; then
  mkdir -p "$DEPS"
  curl -L -s -o /tmp/ndk.zip "https://dl.google.com/android/repository/android-ndk-$NDK_VER-linux.zip" || exit 1
  unzip -q -o /tmp/ndk.zip -d "$DEPS" || exit 1
fi
export ANDROID_NDK="$DEPS/android-ndk-$NDK_VER"

# ---------- 2. SDK (только build-tools, без Android Studio) ----------
step "2/8. SDK build-tools"
export ANDROID_HOME=$DEPS/sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
BT="$ANDROID_HOME/build-tools/$BT_VER"
if [ ! -d "$BT" ]; then
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    curl -L -s -o /tmp/cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
    unzip -q -o /tmp/cmdtools.zip -d /tmp/cmdtools
    mv /tmp/cmdtools/cmdline-tools "$ANDROID_HOME/cmdline-tools/latest"
  fi
  yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_HOME" --licenses > /dev/null
  "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_HOME" \
      "platforms;android-34" "build-tools;$BT_VER" > /dev/null
fi

# ---------- 3. Исходники ----------
step "3/8. Клонирование SDL2, McEngine, McOsu"
clone_or_pull() {  # $1=url $2=dir $3=tag
  if [ -d "$2/.git" ]; then git -C "$2" fetch --depth 1 origin "$3" && git -C "$2" checkout -q FETCH_HEAD; \
  else git clone --depth 1 --branch "$3" "$1" "$2"; fi
}
clone_or_pull https://github.com/libsdl-org/SDL.git "$DEPS/sdl" "$SDL_TAG" || exit 1
clone_or_pull https://github.com/McKay42/McEngine.git "$DEPS/McEngine" master
clone_or_pull https://github.com/McKay42/McOsu.git "$DEPS/McOsu" master

# ---------- 4. SDL2 (shared lib) ----------
step "4/8. Сборка SDL2"
cmake -S "$DEPS/sdl" -B "$BUILD/sdl" \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=$ABI -DANDROID_PLATFORM=android-$ANDROID_API \
  -DANDROID_STL=c++_shared \
  -DSDL_SHARED=ON -DSDL_STATIC=OFF -DSDL_TESTS=OFF || exit 1
cmake --build "$BUILD/sdl" -j"$(nproc)" || exit 1

# ---------- 5. libmain.so (McEngine + McOsu) ----------
step "5/8. Сборка libmain.so (McEngine + McOsu)"
cmake -S "$ROOT/android/cmake" -B "$BUILD/main" \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=$ABI -DANDROID_PLATFORM=android-$ANDROID_API \
  -DANDROID_STL=c++_shared \
  -DMCENGINE_DIR="$DEPS/McEngine" -DMCOSU_DIR="$DEPS/McOsu" \
  -DSDL2_DIR="$DEPS/sdl" -DSDL2_BUILD="$BUILD/sdl" || exit 1
cmake --build "$BUILD/main" -j"$(nproc)" || exit 1

# ---------- 6. Java-слой (SDLActivity из исходников SDL) ----------
step "6/8. Java: SDLActivity -> classes.dex"
rm -rf "$BUILD/java" "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"
mkdir -p "$BUILD/java" "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"
cp -r "$DEPS/sdl/android-project/app/src/main/java/org" "$BUILD/java/"
# Мы собираем SDL2 в libmain? Нет: SDL2 shared отдельно, а hidapi не собираем — вырезаем его загрузку.
# HIDAPI не собираем (тач-управление) — комментируем его загрузку
sed -i 's|System.loadLibrary("hidapi");|// System.loadLibrary("hidapi");|' \
    "$BUILD/java/org/libsdl/app/SDLActivity.java"
JAR="$ANDROID_HOME/platforms/android-34/android.jar"
find "$BUILD/java" "$ROOT/android/src" -name '*.java' > "$BUILD/java.list"
javac -encoding UTF-8 -classpath "$JAR" -d "$BUILD/classes" @"$BUILD/java.list" || exit 1
"$BT/d8" --lib "$JAR" --output "$BUILD/dex" "$BUILD/classes" || exit 1

# ---------- 7. Сборка APK ----------
step "7/8. aapt2 -> APK -> zipalign -> sign"
mkdir -p "$UNZ/lib/$ABI" "$BUILD/resout"
cp "$BUILD/sdl/libSDL2.so" "$UNZ/lib/$ABI/"
cp "$BUILD/main/libmain.so" "$UNZ/lib/$ABI/"
cp "$ANDROID_NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so" "$UNZ/lib/$ABI/"
"$BT/aapt2" compile --dir "$ROOT/android/res" -o "$BUILD/resout/res.zip" || exit 1
"$BT/aapt2" link -o "$BUILD/unsigned.apk" \
  -I "$JAR" --java "$BUILD/gen" --manifest "$ROOT/android/AndroidManifest.xml" \
  --min-sdk-version $ANDROID_API --target-sdk-version 34 \
  "$BUILD/resout/res.zip" || exit 1
(cd "$BUILD/dex" && zip -q -X "$BUILD/unsigned.apk" classes.dex)
(cd "$UNZ" && zip -q -r -X "$BUILD/unsigned.apk" "lib/*")
"$BT/zipalign" -f 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk" || exit 1
if [ ! -f "$BUILD/debug.keystore" ]; then
  keytool -genkeypair -keystore "$BUILD/debug.keystore" -alias androiddebugkey \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass android -keypass android -dname "CN=Debug,O=Dev,C=RU" > /dev/null 2>&1
fi
mkdir -p "$OUT"
"$BT/apksigner" sign --ks "$BUILD/debug.keystore" --ks-pass pass:android \
  --out "$OUT/mcosu.apk" "$BUILD/aligned.apk" || exit 1
echo; echo "=== ГОТОВО: out/mcosu.apk ==="
