cmake_minimum_required(VERSION 3.22)
project(mcosu_android CXX C)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# --- Пути передаются из build-apk.sh ---
set(MCENGINE_DIR "" CACHE PATH "Path to McEngine sources")
set(MCOSU_DIR    "" CACHE PATH "Path to McOsu sources")
set(SDL2_DIR     "" CACHE PATH "Path to SDL2 sources")
set(SDL2_BUILD   "" CACHE PATH "Path to SDL2 cmake build dir")

# --- Исходники: сначала берём ВСЁ, потом вырезаем то, что точно не нужно на Android.
# Первые упавшие сборки подскажут, что ещё исключить (см. docs/PORTING_NOTES.md).
file(GLOB_RECURSE MCENGINE_SRC CONFIGURE_DEPENDS
    ${MCENGINE_DIR}/*.cpp ${MCENGINE_DIR}/*.c ${MCENGINE_DIR}/*.cc)
file(GLOB_RECURSE MCOSU_SRC CONFIGURE_DEPENDS
    ${MCOSU_DIR}/*.cpp ${MCOSU_DIR}/*.c)

# Типичные десктоп-файлы, которые не должны собираться на Android.
# Дополняй этот список по мере ошибок компиляции (неизвестные заголовки WinAPI/X11).
list(FILTER MCENGINE_SRC EXCLUDE REGEX ".*/(Win32|Windows|X11|Linux|MacOS|WinEnvironment|SDL2?/).*")
list(FILTER MCENGINE_SRC EXCLUDE REGEX ".*(win32|windows|_win|WinAPI).*[.](cpp|c)$")

# TODO(порт): если в McEngine нет готового android_main/loader'а приложения —
# android_main.cpp ниже вызывает SDL_main, который должен загрузить приложение.
add_library(main SHARED
    ${CMAKE_CURRENT_SOURCE_DIR}/../src/android_main.cpp
    ${MCENGINE_SRC}
    ${MCOSU_SRC})

# TODO(порт): уточнить include-пути по реальной структуре репозиториев
target_include_directories(main PRIVATE
    ${MCENGINE_DIR}
    ${MCENGINE_DIR}/src
    ${MCOSU_DIR}
    ${MCOSU_DIR}/src
    ${SDL2_DIR}/include
    ${SDL2_BUILD}/include            # сгенерированный SDL_build_config.h
    ${CMAKE_CURRENT_SOURCE_DIR})    # здесь можно класть shim-заголовки

# GLES2 для начала; McEngine-патч под GLES3 при необходимости
find_library(lib_gl GLESv2)
find_library(lib_egl EGL)
find_library(lib_log log)
find_library(lib_android android)
find_library(lib_OpenSLES OpenSLES)

# SDL2 собран shared -> линкуем по пути из его билд-директории
target_link_directories(main PRIVATE ${SDL2_BUILD})
target_link_libraries(main PRIVATE
    SDL2
    ${lib_gl} ${lib_egl}
    ${lib_log} ${lib_android}
    ${lib_OpenSLES}
    c++_shared z m)
