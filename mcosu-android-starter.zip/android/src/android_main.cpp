// Точка входа Android-порта McEngine/McOsu.
// SDL2 под Android требует SDL_main вместо main (см. SDL_main.h).
//
// TODO(порт): в McEngine есть свой загрузчик приложения (класс App, создаётся
// конкретное приложение McOsu). Найди в исходниках десктопную main() и вызови
// отсюда то же самое: создание окна/окружения и запуск Osu.
//
// TODO(порт): временно можно вернуть 0 и просто отрисовать SDL-окно,
// чтобы проверить пайплайн APK до того, как подключать движок целиком.

#include <SDL.h>
#include <SDL_main.h>
#include <GLES2/gl2.h>

extern "C" int SDL_main(int argc, char* argv[])
{
    SDL_Log("McOsu Android: SDL_main старт, argc=%d", argc);

    // Заглушка-проверка пайплайна: открываем окно на 2 секунды.
    // Как только APK доходит до этого экрана — заменяем на запуск McEngine.
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) < 0) {
        SDL_Log("SDL_Init failed: %s", SDL_GetError());
        return 1;
    }
    SDL_Window* w = SDL_CreateWindow("McOsu Port",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 720,
        SDL_WINDOW_OPENGL | SDL_WINDOW_FULLSCREEN_DESKTOP | SDL_WINDOW_SHOWN);
    if (!w) {
        SDL_Log("SDL_CreateWindow failed: %s", SDL_GetError());
        return 1;
    }
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
    SDL_GLContext ctx = SDL_GL_CreateContext(w);
    SDL_Log("GL context: %s", ctx ? "OK" : SDL_GetError());

    SDL_Event e;
    Uint32 start = SDL_GetTicks();
    bool run = true;
    while (run) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) run = false;
            if (e.type == SDL_FINGERDOWN) {
                SDL_Log("touch at %.0f,%.0f", e.tfinger.x, e.tfinger.y);
                run = false; // тап = закрыть (это только тест пайплайна)
            }
        }
        if (SDL_GetTicks() - start > 3000) run = false;
        glClearColor(1.0f, 0.5f, 0.0f, 1.0f); // оранжевый фон
        glClear(GL_COLOR_BUFFER_BIT);
        SDL_GL_SwapWindow(w);
    }
    SDL_Quit();
    return 0;
}
